document.getElementById("enter").onclick = function() {
   location.href = "allfeature.html";
};
