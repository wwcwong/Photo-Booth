Zijun Zhou 999232507
Judy Cheng 999647354
Ricky Wong 913374195
///////
put html, js, css files in ./public; put photos.db and finalserver.js to root directory; put photobooth direcotry in ./public
